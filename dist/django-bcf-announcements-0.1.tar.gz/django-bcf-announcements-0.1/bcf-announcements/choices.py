IMPORTANCE_CHOICES = (
    ('alert-info', 'Normal'),
    ('alert-warning', 'High'),
    ('alert-danger', 'Critical'),
)

DISMISSAL_CHOICES = (
    ('none', 'none'),
    ('permanent', 'permanent'),
)
